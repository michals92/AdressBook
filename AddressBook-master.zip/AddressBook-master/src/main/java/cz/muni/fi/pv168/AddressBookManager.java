package cz.muni.fi.pv168;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: zitoo
 * Date: 25.2.12
 * Time: 17:03
 * To change this template use File | Settings | File Templates.
 */
public interface AddressBookManager {

    public void addContactToPerson(Person person, Contact contact);
    public List<Contact> getContactsOfPerson(Person person);
    public void removeContactFromPerson(Contact contact, Person person);
    public void removeAllContactsFromPerson(Person person);

}