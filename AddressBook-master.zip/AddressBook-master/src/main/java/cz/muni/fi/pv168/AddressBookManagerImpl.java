package cz.muni.fi.pv168;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: zitoo
 * Date: 6.3.12
 * Time: 14:02
 * To change this template use File | Settings | File Templates.
 */
public class AddressBookManagerImpl implements AddressBookManager {
    @Override
    public void addContactToPerson(Person person, Contact contact) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public List<Contact> getContactsOfPerson(Person person) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void removeContactFromPerson(Contact contact, Person person) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void removeAllContactsFromPerson(Person person) {
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
