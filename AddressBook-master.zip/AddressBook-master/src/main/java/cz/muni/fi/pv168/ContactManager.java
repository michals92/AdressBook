package cz.muni.fi.pv168;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: zitoo
 * Date: 25.2.12
 * Time: 16:30
 * To change this template use File | Settings | File Templates.
 */
public interface ContactManager  {

    /**
     * Creates contact in datastore and returns new instance with assigned ID
     * @param contact contact to create, can't be null and can't have ID assigned
     * @param person Person to attach the contact to
     * @throws IllegalArgumentException when contact has ID assigned or person has no ID
     * @throws ServiceFailureException when datastore fails
     * @return instance of contact with ID assigned
     */
    public Contact createContact(Contact contact, Person person) throws ServiceFailureException;

    /**
     * Finds all contacts in datastore and returns them in a List.
     * @throws ServiceFailureException when datastore fails
     * @return List of contacts, may be empty
     */
    public List<Contact> findAllContacts() throws ServiceFailureException;

    /**
     * Find contact with specified ID in datastore and returns it.
     * @param id id of the contact
     * @throws ServiceFailureException when datastore fails
     * @return instance of contact or null if not found
     */
    public Contact findContactById(Long id) throws ServiceFailureException;
    
    
    /**
     * Find contact bound with the specified person.
     * @param person person to look for, must have ID assigned
     * @throws ServiceFailureException when datastore fails
     * @return instance of contact or null if not found
     */
    public List<Contact> findContactsByPerson(Person person) throws ServiceFailureException;


    /**
     * Updates contact in datastore with new properties.
     * @param contact Contact to be updated with new info.
     * @throws IllegalArgumentException when contact has no ID
     * @throws ServiceFailureException when datastore fails
     */
    public void updateContact(Contact contact) throws ServiceFailureException;
    
   
    /**
     * Deletes specified contact from datastore. If the contact doesn't exists nothing happens.
     * @param contact contact to be deleted, must have ID assigned
     * @throws IllegalArgumentException when contact has no ID assigned
     * @throws ServiceFailureException when datastore fails
     */
    public void deleteContact(Contact contact) throws ServiceFailureException;
}