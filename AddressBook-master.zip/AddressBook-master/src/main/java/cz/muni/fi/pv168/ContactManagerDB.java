package cz.muni.fi.pv168;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

/**
 * Created by IntelliJ IDEA. User: xtrantin Date: 27.3.12 Time: 11:07 To change
 * this template use File | Settings | File Templates.
 */
public class ContactManagerDB implements ContactManager {
	private static final Logger log = LoggerFactory.getLogger(ContactManagerDB.class);

	private JdbcTemplate jdbc;

	public ContactManagerDB(DataSource dataSource) {
		if (dataSource == null) {
			throw new NullPointerException("datasource");
		}

		this.jdbc = new JdbcTemplate(dataSource);
	}

	@Override
	public Contact createContact(Contact contact, Person person) throws ServiceFailureException {
		if(contact==null) 
			throw new NullPointerException("contact");
		if(contact.getId()!=null)
			throw new IllegalArgumentException("contact has ID assigned");
		if(person==null)
			throw new NullPointerException("person");
		if(person.getId()==null)
			throw new IllegalArgumentException("person has no id");


		try {
			SimpleJdbcInsert ins = new SimpleJdbcInsert(jdbc)
			.withTableName("contacts").usingGeneratedKeyColumns("id");
			Map<String, Object> values = new HashMap<String, Object>();
			values.put("type", contact.getType());
			values.put("value", contact.getValue());
			values.put("person", person.getId());
			contact.setId(ins.executeAndReturnKey(values).longValue());

			return contact;
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		}


	}

	@Override
	public List<Contact> findAllContacts() throws ServiceFailureException {
		try {
			return jdbc.query("SELECT * FROM contacts", CONTACT_ROW_MAPPER);
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		}

	}

	@Override
	public Contact findContactById(Long id) throws ServiceFailureException {
		if (id == null)
			throw new NullPointerException("id");

		try {
			List<Contact> res = jdbc.query("SELECT * FROM contacts WHERE id=?", CONTACT_ROW_MAPPER, id);
			if (res.isEmpty()) {
				return null;
			}

			return res.get(0);
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		}

	}

	@Override
	public void updateContact(Contact contact) throws ServiceFailureException {
		if(contact==null)
			throw new NullPointerException("contact");
		if(contact.getId()==null)
			throw new IllegalArgumentException("contact has null id");

		try {
			jdbc.update("UPDATE contacts SET type=?, value=? WHERE id=?", contact.getType(), contact.getValue(), contact.getId());
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		}

	}

	@Override
	public void deleteContact(Contact contact) throws ServiceFailureException {
		if(contact==null)
			throw new NullPointerException("contact");
		if(contact.getId()==null)
			throw new IllegalArgumentException("contact has null id");

		try {
			jdbc.update("DELETE FROM contacts WHERE id=?", contact.getId());
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		}

	}

	@Override
	public List<Contact> findContactsByPerson(Person person) throws ServiceFailureException {
		if(person==null)
			throw new NullPointerException("person");
		if(person.getId()==null)
			throw new IllegalArgumentException("person has no ID");

		try {
			return jdbc.query("SELECT * FROM contacts WHERE person=?", CONTACT_ROW_MAPPER, person.getId());
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		}
	}

	private static final RowMapper<Contact> CONTACT_ROW_MAPPER = new RowMapper<Contact>() {
		@Override
		public Contact mapRow(ResultSet rs, int i) throws SQLException {
			Contact contact = new Contact();
			contact.setId(rs.getLong("id"));
			contact.setType(rs.getString("type"));
			contact.setValue(rs.getString(("value")));
			return contact;
		}
	};

}
