package cz.muni.fi.pv168;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Locale;
import java.util.MissingResourceException;
import java.util.ResourceBundle;

import javax.sql.DataSource;

import org.apache.tomcat.dbcp.dbcp.BasicDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/**
 * Simplifies creation of DB connections. 
 * Info about connection is loaded from database.properties in which 3 keys must exist.
 * path-the complete jdbc connection url to the database
 * username- username to the specified db
 * password- password to the specified db
 * 
 * @author Coffei
 *
 */
public class DBUtils {

	private static final Logger log = LoggerFactory.getLogger(DBUtils.class);


	/**
	 * Return's connection to database.
	 * @return connection to database
	 * @throws MissingResourceException when properties file is missing
	 * @throws SQLException when connection fails
	 * @deprecated will be deleted in future updates
	 */
	@Deprecated
	public static Connection getConnection() throws SQLException {

		SpringConfig config = new SpringConfig();
		return config.dataSource().getConnection();

	}

	
	

	/**
	 * Closes passed connection catching and logging any exceptions that occur.
	 * @param connection connection to close, can't be null
	 * @throws NullPointerException when connection is null
	 * @deprecated will be deleted in future updates
	 */
	@Deprecated
	public static void closeConnection(Connection connection) {
		if(connection==null) {
			log.warn("closeConnection with null connection");
			throw new NullPointerException("connection");
		}

		try {
			connection.close();
		} catch (SQLException e) {
			log.error("error closing DB connection", e);
		}
	}
	
	
	public static ApplicationContext getAppContext() {
		return new AnnotationConfigApplicationContext(SpringConfig.class);
	}

	@Configuration  
	@EnableTransactionManagement 
	public static class SpringConfig {
		
		private static final String PATH_KEY = "path";
		private static final String USERNAME_KEY = "username";
		private static final String PASSWORD_KEY = "password";
		private static final String DATABASE_PROP_KEY = "cz.muni.fi.pv168.database";

		private static String dbPath=null;
		private static String username=null;
		private static String password=null;
		
		private static boolean tablesCreated = false;
		
		@Bean
		public DataSource dataSource() {
			if(dbPath==null || username==null || password==null) {
				initialize();
			}
			
			BasicDataSource bds = new BasicDataSource();
			bds.setDriverClassName("org.apache.derby.jdbc.EmbeddedDriver");
			bds.setUrl(dbPath);
			bds.setUsername(username);
			bds.setPassword(password);
			
			if(!tablesCreated) {
				try {
					createTables(bds.getConnection());
				} catch (SQLException e) {
					log.error("error getting connection on table creation",e);
				}
			}
			
			return bds;
		}

		@Bean 
		public PlatformTransactionManager transactionManager() {
			return new DataSourceTransactionManager(dataSource());
		}
		
		@Bean
		public GroupManager groupManager() {
			return new GroupManagerDB(dataSource());
		}
		
		@Bean
		public ContactManager contactManager() {
			return new ContactManagerDB(dataSource());
		}

        @Bean
        public PersonManager personManager(){
            return new PersonManagerImpl(dataSource());

        }
		
		//HERE add other managers you want to use
		
		public static void initialize() {
			tablesCreated = false;
			try {
				ResourceBundle bundle = ResourceBundle.getBundle(DATABASE_PROP_KEY, Locale.ROOT);
				if(bundle.containsKey(PATH_KEY) && bundle.containsKey(USERNAME_KEY) && bundle.containsKey(PASSWORD_KEY)) {
					dbPath = bundle.getString(PATH_KEY);
					username = bundle.getString(USERNAME_KEY);
					password = bundle.getString(PASSWORD_KEY);
				} else {
					throw new MissingResourceException("missing keys", DBUtils.class.toString(), DATABASE_PROP_KEY);
				}
			} catch (MissingResourceException e) {
				log.error("missing properties file", e);
				throw e;
			}

		}
		
		//Is there a better way to do this?
		private static void createTables(Connection connection) {
			if(connection==null) {
				log.warn("creating tables with null connection");
				return;
			}
		
			try {
				Statement st = connection.createStatement();

				ResultSet tables = connection.getMetaData().getTables(null, null, "GROUPS", null);
				if(!tables.next()) {

					try {
						st.execute("CREATE TABLE Groups (id BIGINT NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
								"name VARCHAR(255))");

					} catch (SQLException e) {
						log.debug("creating table groups, that exists already", e);
					}
				}

				tables = connection.getMetaData().getTables(null, null, "PERSON", null);
				if(!tables.next()) {
					try {
						st.execute("CREATE TABLE Person(id BIGINT NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY," +
								"name VARCHAR(255), born DATE)");


					} catch (SQLException e) {
						log.debug("creating table person, that exists already", e);
					}
				}

				tables = connection.getMetaData().getTables(null, null , "MEMBERSHIPS", null);
				if(!tables.next()) {
					try {
						st.execute("CREATE TABLE Memberships (person BIGINT NOT NULL, " +
								"grp BIGINT NOT NULL, PRIMARY KEY (person, grp))");


					} catch (SQLException e) {
						log.debug("creating table memberships, that exists already", e);
					}
				}
				
				tables = connection.getMetaData().getTables(null, null, "CONTACTS", null);
				if(!tables.next()) {
					try {
						st.execute("CREATE TABLE Contacts (id BIGINT NOT NULL PRIMARY KEY GENERATED ALWAYS AS IDENTITY, " +
								"person BIGINT, type VARCHAR(255), value LONG VARCHAR)");


					} catch (SQLException e) {
						log.debug("creating table memberships, that exists already", e);
					}
				}
				
				//HERE add other tables you want to create when not exists

				tablesCreated = true;
			} catch (SQLException e1) {
				log.error("DB error, getting statement", e1);
			}




		}

	}

	



}
