package cz.muni.fi.pv168;

/**
 * JavaBean, represents group of people
 * User: Coffei
 * Date: 28.2.12
 * Time: 15:04
 */
public class Group {
	
	public Group() {
	}
	
	/**
	 * Copy constructor, doesn't copy ID!
	 * @param group group to be copied
	 */
	public Group(Group group) {
		this.name = group.name;
	}

    private Long id;
    private String name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Group group = (Group) o;

        if (id != null ? !id.equals(group.id) : group.id != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}