package cz.muni.fi.pv168;

import java.util.List;

/**
 * Manager for Group instances
 * User: Coffei
 * Date: 28.2.12
 * Time: 15:12
 */
public interface GroupManager {

    /**
     * Creates new group in datastore. ID is generated and assigned to new group's attribute.
     * @param group group to be created
     * @return created group with ID assigned
     * @throws IllegalArgumentException when group has ID set
     * @throws NullPointerException when group is null
     * @throws ServiceFailureException when datastore operation fails
     */
    Group createGroup(Group group) throws ServiceFailureException ;

    /**
     * Deletes existing group from datastore.
     * @param group group to be deleted
     * @throws IllegalArgumentException when group has no ID
     * @throws NullPointerException when group is null
     * @throws ServiceFailureException when datastore operation fails
     */
    void deleteGroup(Group group) throws ServiceFailureException;

    /**
     * Updates group in datastore.
     * @param group group to update
     * @throws IllegalArgumentException when group has no ID
     * @throws NullPointerException when group is null
     * @throws ServiceFailureException when datastore operation fails
     */
    void updateGroup(Group group) throws ServiceFailureException;

    /**
     * Returns group with specified ID.
     * @param id ID of the group to be returned
     * @return group or null if not found
     * @throws NullPointerException if ID is null
     * @throws ServiceFailureException if datastore operation fails
     */
    Group findGroupById(Long id) throws ServiceFailureException;

    /**
     * Returns list of all groups in datastore.
     * @return list of groups, maybe empty
     * @throws ServiceFailureException if datastore operation fails
     */
    List<Group> findAllGroups() throws ServiceFailureException;

    /**
     * Associates Person with Group.
     * @param person Person to be associated with a group.
     * @param group Group to be associated with a person.
     * @throws IllegalArgumentException when person or group has no ID
     * @throws NullPointerException when person or group is null
     * @throws ServiceFailureException if datastore operation fails
     */
    void addPersonToGroup(Person person, Group group) throws ServiceFailureException;

    /**
     * Remove a bond between Person and Group. If the bond doesn't exists, nothing happens.
     * @param person Person to remove a bond from.
     * @param group Group to remove a bond from.
     * @throws NullPointerException if person or group is null
     * @throws IllegalArgumentException if person or group has no ID
     * @throws ServiceFailureException if datastore operation fails.
     */
    void removePersonFromGroup(Person person, Group group) throws ServiceFailureException;

    /**
     * Returns all Groups associated with specified Person.
     * @param person Person whose groups should be searched for.
     * @return List of groups or empty list.
     * @throws NullPointerException if person is null
     * @throws ServiceFailureException when datastore operation fails
     */
    List<Group> findGroupsByPerson(Person person) throws ServiceFailureException;

    /**
     * Returns all Persons associated with specified Group.
     * @param group Group whose persons should be searched for.
     * @return List of groups or empty list.
     * @throws NullPointerException if group is null
     * @throws ServiceFailureException when datastore operation fails.
     */
    List<Person> findAllPersonsInGroup(Group group) throws ServiceFailureException;
}