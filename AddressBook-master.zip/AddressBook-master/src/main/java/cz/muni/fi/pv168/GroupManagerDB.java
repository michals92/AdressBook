package cz.muni.fi.pv168;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.MissingResourceException;

import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

/**
 * Database GroupManager.
 * @author Coffei
 *
 */
public class GroupManagerDB implements GroupManager {
	private static final Logger log = LoggerFactory.getLogger(GroupManagerDB.class);
	
	private JdbcTemplate jdbc;
	
	
	public GroupManagerDB(DataSource dataSource) {
		if(dataSource == null)
			throw new NullPointerException("datasource");
		
		this.jdbc = new JdbcTemplate(dataSource);
	}
	
	@Override
	public Group createGroup(Group group) throws ServiceFailureException {
		if(group==null) {
			log.warn("createGroup with null group");
			throw new NullPointerException("group");
		}
		if(group.getId()!=null) {
			log.warn("createGroup with null groups ID");
			throw new IllegalArgumentException("group has ID set");
		}

		try {
			SimpleJdbcInsert ins = new SimpleJdbcInsert(jdbc)
								.withTableName("groups").usingGeneratedKeyColumns("id");
			Map<String, Object> values = new HashMap<String, Object>();
			values.put("name", group.getName());
			group.setId(ins.executeAndReturnKey(values).longValue());
			
			return group;
		} catch (DataAccessException e)	{
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		}

	}
	
	@Override
	public void deleteGroup(Group group) throws ServiceFailureException {
		if(group==null) {
			log.warn("deleteGroup with null group");
			throw new NullPointerException("group");
		}
		if(group.getId()==null) {
			log.warn("deleteGroup with null groups ID");
			throw new IllegalArgumentException("group has no id");
		}

		try {
			jdbc.update("DELETE FROM groups WHERE id=?", group.getId());
			
		} catch (DataAccessException e) {
			log.error("DB error");
			throw new ServiceFailureException(e);
		}

	}

	
	@Override
	public void updateGroup(Group group) throws ServiceFailureException {
		if(group==null) {
			log.warn("updateGroup with null group");
			throw new NullPointerException("group");
		}
		if(group.getId()==null) {
			log.warn("updateGroup with null groups ID");
			throw new IllegalArgumentException("group has no id");
		}

		try {
			jdbc.update("UPDATE groups SET name=? WHERE id=?", group.getName(), group.getId());

		} catch(DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		} 
	}
	
	@Override
	public Group findGroupById(Long id) throws ServiceFailureException {
		if(id==null) {
			log.warn("findGroup with null ID");
			throw new NullPointerException("id");
		}

		
		try {
			List<Group> groups = jdbc.query("SELECT * FROM groups WHERE id=?", GROUP_ROW_MAPPER, id);
			if(groups.isEmpty())
				return null;
			
			return groups.get(0);

		} catch(DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		} 
	}
	

	

	@Override
	public List<Group> findAllGroups() throws ServiceFailureException {
		try {
			
			return jdbc.query("SELECT * FROM groups", GROUP_ROW_MAPPER);

		} catch(DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		} 

	}
	
	@Override
	public void addPersonToGroup(Person person, Group group)
			throws ServiceFailureException {
		if (person==null)
			throw new NullPointerException("person");
		if(group==null)
			throw new NullPointerException("group");
		if(person.getId()==null)
			throw new IllegalArgumentException("person has null ID");
		if(group.getId()==null)
			throw new IllegalArgumentException("group has null ID");
		
		try {
			SimpleJdbcInsert ins = new SimpleJdbcInsert(jdbc).withTableName("memberships");
			Map<String, Object> values = new HashMap<String, Object>();
			values.put("person", person.getId());
			values.put("grp", group.getId());
			
			ins.execute(values);
			
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		} 
		
		

	}

	
	@Override
	public void removePersonFromGroup(Person person, Group group)
			throws ServiceFailureException {
		if(person==null)
			throw new NullPointerException("person");
		if(group==null)
			throw new NullPointerException("group");
		if(person.getId()==null) 
			throw new IllegalArgumentException("person has null id");
		if(group.getId()==null)
			throw new IllegalArgumentException("group has null id");
		
		try {
			jdbc.update("DELETE FROM memberships WHERE person=? AND grp=?", person.getId(), group.getId());
			
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		} 

	}
	
	
	@Override
	public List<Group> findGroupsByPerson(Person person)
			throws ServiceFailureException {
		if(person==null)
			throw new NullPointerException("person");
		if(person.getId()==null) 
			throw new IllegalArgumentException("person has null id");
		
		try {
			return jdbc.query("SELECT * FROM memberships, groups WHERE grp=id AND " +
									"person=?", GROUP_ROW_MAPPER, person.getId());
			
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		} 
	}
	
	@Override
	public List<Person> findAllPersonsInGroup(Group group)
			throws ServiceFailureException {
		if(group==null)
			throw new NullPointerException("group");
		if(group.getId()==null) 
			throw new IllegalArgumentException("group has null id");

		try {
			return jdbc.query("SELECT * FROM memberships, person WHERE person=id AND grp=?", PersonManagerImpl.PERSON_ROW_MAPPER, group.getId());
			
		} catch (DataAccessException e) {
			log.error("DB error", e);
			throw new ServiceFailureException(e);
		} 
	}
	
	
	
	
	
	private static final RowMapper<Group> GROUP_ROW_MAPPER = new RowMapper<Group>() {
		
		@Override
		public Group mapRow(ResultSet rs, int rowNum) throws SQLException {
			Group group = new Group();
			group.setId(rs.getLong("id"));
			group.setName(rs.getString("name"));
			
			return group;
		}
	};
	
	


}
