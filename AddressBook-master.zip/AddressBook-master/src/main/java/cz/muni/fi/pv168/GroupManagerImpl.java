package cz.muni.fi.pv168;

import java.util.List;

/**
 * Created by IntelliJ IDEA.
 * User: zitoo
 * Date: 6.3.12
 * Time: 14:01
 * To change this template use File | Settings | File Templates.
 */
public class GroupManagerImpl implements GroupManager {
    @Override
    public Group createGroup(Group group) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void deleteGroup(Group group) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void updateGroup(Group group) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public Group findGroupById(Long id) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public List<Group> findAllGroups() {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void addPersonToGroup(Person person, Group group) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public void removePersonFromGroup(Person person, Group group) {
        //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public List<Group> findGroupsByPerson(Person person) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }

    @Override
    public List<Person> findAllPersonsInGroup(Group group) {
        return null;  //To change body of implemented methods use File | Settings | File Templates.
    }
}
