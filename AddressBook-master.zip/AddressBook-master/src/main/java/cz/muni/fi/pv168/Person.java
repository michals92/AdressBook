package cz.muni.fi.pv168;

import java.util.Calendar;

/**
 * Created by IntelliJ IDEA.
 * User: zitoo
 * Date: 22.2.12
 * Time: 18:17
 * To change this template use File | Settings | File Templates.
 */
public class Person {
    private Long id;
    private String name;
    private Calendar born;

    public Long getId() {

        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Calendar getBorn() {
        return born;
    }

    public void setBorn(Calendar born) {
        this.born = born;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        Person person = (Person) o;

        if (born != null ? !born.equals(person.born) : person.born != null) return false;
        if (id != null ? !id.equals(person.id) : person.id != null) return false;
        if (name != null ? !name.equals(person.name) : person.name != null) return false;

        return true;
    }

    @Override
    public int hashCode() {
        int result = id != null ? id.hashCode() : 0;
        result = 31 * result + (name != null ? name.hashCode() : 0);
        result = 31 * result + (born != null ? born.hashCode() : 0);
        return result;
    }

    @Override
    public String toString() {
        return "Person{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", born=" + born +
                '}';
    }
}