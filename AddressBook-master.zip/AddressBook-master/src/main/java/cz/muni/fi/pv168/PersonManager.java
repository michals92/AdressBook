package cz.muni.fi.pv168;

import java.util.List;

/**
 * Store Person in datastore and offer basic CRUD operation.
 *
 * User: Martin Zitnik
 * Date: 25.2.12
 * Time: 16:30
 */
public interface PersonManager {
    /**
     *  Store person in datastore and assign id to him.
     *
     * @param person to be stored.
     * @throws NullPointerException when person is not set.
     * @throws IllegalArgumentException when person has id.
     * @throws ServiceFailureException when is problem with datastore.
     * @return stored person with generated ID.
     */
    public Person createPerson(Person person);


    /**
     * Return list of all persons stored.
     *
     * @throws ServiceFailureException when is problem with datastore.
     * @return Listo of all persons stored.
     */
    public List<Person> findAllPersons();

    /**
     * Return person with specific id.
     *
     * @param id id of the person we are looking for.
     * @throws NullPointerException when id is not set.
     * @throws ServiceFailureException when is problem with datastore.
     * @return Person if found or null.
     */
    public Person findPersonById(Long id);

    /**
     * Update Person with new parameters.
     *
     * @param person to be updated
     * @throws NullPointerException when person is not set.
     * @throws IllegalArgumentException when person has no id.
     * @throws ServiceFailureException when is problem with datastore.
     */
    public void updatePerson(Person person);

    /**
     * Delete person from datastore.
     *
     * @param person to be deleted
     * @throws NullPointerException when person is not set.
     * @throws IllegalArgumentException when person has no id.
     * @throws ServiceFailureException when is probelm with datastore.
     */
    public void deletePerson(Person person);
}