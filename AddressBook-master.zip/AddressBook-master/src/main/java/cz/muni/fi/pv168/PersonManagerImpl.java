package cz.muni.fi.pv168;

import org.apache.derby.iapi.error.StandardException;
import org.apache.derby.iapi.types.SQLDate;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;

import javax.sql.DataSource;
import java.sql.Date;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


/**
 * Created by IntelliJ IDEA.
 * User: zitoo
 * Date: 6.3.12
 * Time: 14:02
 * To change this template use File | Settings | File Templates.
 */
public class PersonManagerImpl implements PersonManager {
    private JdbcTemplate jdbc;

    public PersonManagerImpl(DataSource dataSource) {
        this.jdbc = new JdbcTemplate(dataSource);
    }

    private static final RowMapper<Person> PERSON_ROW_MAPPER = new RowMapper<Person>() {
        @Override
        public Person mapRow(ResultSet rs, int rowNum) throws SQLException {
            Person person = new Person();
            person.setId(rs.getLong("id"));
            person.setName(rs.getString("name"));

            Calendar sqlToCalendar = null;
            if(rs.getDate("born") != null){
                sqlToCalendar = Calendar.getInstance();
                sqlToCalendar.setTime(rs.getDate("born"));
            }

            person.setBorn(sqlToCalendar);
            return person;
        }
    };

    /**
     * Method that converts Calendar to java.sql.Date object.
     *
     * @param person person whoose born parameter should be converted.
     * @return java.sql.Date
     */
    private Date calendarToSqlDate(Person person){
        return person.getBorn() !=null ? new Date(person.getBorn().getTime().getTime()) : null;
    }



    @Override
    public Person createPerson(Person person) {
        if(person == null){
            throw new NullPointerException("Argument is null");
        }
        if(person.getId() != null){
            throw new IllegalArgumentException("Argument has already set id");
        }
        SimpleJdbcInsert insert = new SimpleJdbcInsert(jdbc).withTableName("Person").usingGeneratedKeyColumns("id");
        Map<String, Object> map = new HashMap<String, Object>();
        map.put("name", person.getName());

        Date calendarToSqlDate = calendarToSqlDate(person);

        map.put("born", calendarToSqlDate);
        person.setId(insert.executeAndReturnKey(map).longValue());
        return person;
    }

    @Override
    public List<Person> findAllPersons() {
        return jdbc.query("SELECT * FROM Person", PERSON_ROW_MAPPER);
    }

    @Override
    public Person findPersonById(Long id) {
        if(id == null){
            throw new NullPointerException("Argument is null");
        }
        List<Person> list = jdbc.query("SELECT * FROM Person WHERE id=?", PERSON_ROW_MAPPER, id);

        return list.isEmpty() ? null : list.get(0);
    }


    @Override
    public void updatePerson(Person person) {
        if(person == null){
            throw new NullPointerException("Argument can not not be null");
        }
        if(person.getId() == null){
            throw new IllegalArgumentException("Id is not set");
        }
        Date calendarToSqlDate = calendarToSqlDate(person);
        jdbc.update("UPDATE Person SET name=?,born=? WHERE id=?", person.getName(), calendarToSqlDate(person), person.getId());
    }

    @Override
    public void deletePerson(Person person) {
        if(person == null){
            throw new NullPointerException("Argument is null");
        }
        if(person.getId() == null){
            throw new IllegalArgumentException("Argument has not set id");
        }
        jdbc.update("DELETE FROM Person WHERE id=?", person.getId());
        //To change body of implemented methods use File | Settings | File Templates.
    }
}
