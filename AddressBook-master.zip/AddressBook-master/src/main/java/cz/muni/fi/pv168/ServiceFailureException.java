package cz.muni.fi.pv168;

/**
 * Created by IntelliJ IDEA.
 * User: Coffei
 * Date: 9.3.12
 * Time: 17:57
 * To change this template use File | Settings | File Templates.
 */
public class ServiceFailureException extends Exception {

    public ServiceFailureException() {
        super();
    }
    
    public ServiceFailureException(String msg) {
        super(msg);
    }
    
    public ServiceFailureException(Throwable throwable) {
        super(throwable);
    }
    public ServiceFailureException(String msg, Throwable throwable) {
        super(msg, throwable);
    }

}

