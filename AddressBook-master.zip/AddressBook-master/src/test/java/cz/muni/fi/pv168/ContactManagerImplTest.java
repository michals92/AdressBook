package cz.muni.fi.pv168;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

import java.util.ArrayList;
import java.util.List;

import static org.hamcrest.CoreMatchers.equalTo;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.junit.matchers.JUnitMatchers.hasItem;

/**
 * Test for class ContactManagerImpl
 * User: zitoo
 * Date: 13.3.12
 * Time: 17:34
 */
public class ContactManagerImplTest {
    ContactManager contactManager;
    private static ApplicationContext ctx;
   
    @BeforeClass
    public static void getCtx() throws Exception {
    	ctx = DBUtils.getAppContext();
    }
    
    @Before
    public void setUp() throws Exception {
        contactManager = ctx.getBean("contactManager", ContactManager.class);
    }

    //TODO: FIX
    
   /*@Test
    public void testCreateContactNull() throws Exception {
        try{
            contactManager.createContact(null);
            fail("Should throw NullPointerException");
        } catch(NullPointerException ex) {}
    }

    @Test
    public void testCreateContactWithIDSet() throws Exception  {
        Contact contact = new Contact();
        contact.setId(new Long(1));
        try{
            Contact contact1 = contactManager.createContact(contact);
            fail("Should throw IllegalArgumentException");
        } catch(IllegalArgumentException ex) {}
    }

    @Test
    public void testCreateContactRetrieve() throws Exception {
        Contact contact = new Contact();
        contact.setType("name");
        contact.setValue("Ejhloun");
        Contact contact1 = contactManager.createContact(contact);
        assertThat(contactManager.findAllContacts(), hasItem(contact1));
        Contact c2 = contactManager.findContactById(contact1.getId());
        assertEquals(contact1.getType(), c2.getType());
        assertEquals(contact1.getValue(), c2.getValue());
    }
    
    @Test 
    public void testFindAllContactsWhenNoneIsStored() throws Exception {
        assert(contactManager.findAllContacts().isEmpty());
    }

    @Test
    public void testFindAllContacts() throws Exception {
        Contact contact = new Contact();
        Contact contact1 = new Contact();
        Contact contact2 = new Contact();
        Contact contact3 = contactManager.createContact(contact);
        Contact contact4 = contactManager.createContact(contact1);
        Contact contact5 = contactManager.createContact(contact2);
        
        List<Contact> result = contactManager.findAllContacts();
        
        assertThat(result, hasItem(contact3));
        assertThat(result, hasItem(contact4));
        assertThat(result, hasItem(contact5));
    }

    @Test
    public void testFindContactByIdNull() throws Exception {
        try{
            contactManager.findContactById(null);
            fail("Should throw NullPointerException");
        } catch(NullPointerException ex) {}
    }
    
    @Test
    public void testFindContactByIdNotStored() throws Exception { //expecting empty database
        assertThat(contactManager.findContactById(Long.MIN_VALUE), is(equalTo(null)));
    }

    @Test
    public void testFindContactById() throws Exception {
        Contact contact = new Contact();
        Contact contact1 = contactManager.createContact(contact);
        assertThat(contactManager.findContactById(contact1.getId()), is(equalTo(contact1)));
    }

    @Test
    public void testUpdateContactNull() throws Exception {
        try{
            contactManager.updateContact(null);
            fail("Should throw NullPointerException");
        } catch(NullPointerException ex) {}
    }
    
    @Test
    public void testUpdateContactNotStored() throws Exception {
        Contact contact = new Contact();
       // contact.setId(new Long(1));
        try{
            contactManager.updateContact(contact);
            fail("Should throw IllegalArgumentException");
        } catch(IllegalArgumentException ex) {}
    }

    @Test
    public void testUpdateContact() throws Exception {
        Contact contact = new Contact();
        contact = contactManager.createContact(contact);
        contact.setType("updatedtype");
        contact.setValue("updatedValue");
        contactManager.updateContact(contact);
        assertThat(contactManager.findContactById(contact.getId()), is(equalTo(contact)));
    }

    @Test
    public void testDeleteContactNull() throws Exception {
        try{
            contactManager.deleteContact(null);
            fail("Should throw NullPointerException");
        } catch(NullPointerException ex) {}
    }
    
    @Test
    public void testDeleteContactNotStored() throws Exception {
        Contact contact = new Contact();
        //contact.setId(new Long(1));
        try{
            contactManager.deleteContact(contact);
            fail("Should throw IllegalArgumentException");
        } catch(IllegalArgumentException ex) {}
    }

    @Test
    public void testDeleteContact() throws Exception {
        Contact c = new Contact();
        c = contactManager.createContact(c);
        assertThat(contactManager.findAllContacts(), hasItem(c));
        contactManager.deleteContact(c);
        assertThat(contactManager.findAllContacts(), not(hasItem(c)));
        

    }*/
}
