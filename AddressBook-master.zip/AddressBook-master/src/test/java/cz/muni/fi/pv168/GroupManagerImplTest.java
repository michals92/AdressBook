package cz.muni.fi.pv168;

import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNotSame;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.junit.matchers.JUnitMatchers.hasItem;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.context.ApplicationContext;

/**
 * Created by IntelliJ IDEA.
 * User: Coffei
 * Date: 7.3.12
 * Time: 14:00
 * To change this template use File | Settings | File Templates.
 */
public class GroupManagerImplTest {
	static ApplicationContext ctx;
	GroupManager manager;

	@BeforeClass
	public static void getCtx() throws Exception {
		ctx = DBUtils.getAppContext();
	}
	
	
	@Before
	public void setUp() throws Exception {
		manager = ctx.getBean("groupManager", GroupManager.class);
	}

	private PersonManager getPersonManagerInstance() {
		return new PersonManager() { //MOCK

			@Override
			public void updatePerson(Person person) {
				throw new RuntimeException();

			}

		
			@Override
			public Person findPersonById(Long id) {
				throw new RuntimeException();
			}

			@Override
			public List<Person> findAllPersons() {
				throw new RuntimeException();
			}

			@Override
			public void deletePerson(Person person) {
				throw new RuntimeException();

			}

			
			@Override
			public Person createPerson(Person person) {
				Connection conn =null;
				try {
					conn = DBUtils.getConnection();
					
					PreparedStatement st = conn.prepareStatement("INSERT INTO person (name,born) VALUES (?,?)", Statement.RETURN_GENERATED_KEYS);

					st.setString(1, person.getName());
					Calendar born = person.getBorn();
					if(born!=null) {
						st.setDate(2, new Date(born.getTimeInMillis()));
					} else {
						st.setDate(2, null);
					}
					st.execute();

					ResultSet keys = st.getGeneratedKeys();
					
					if (keys.next()) {
						long id = keys.getBigDecimal(1).longValue();
						Person res = new Person();
						res.setName(person.getName());
						res.setBorn(person.getBorn());
						res.setId(id);
						return res;
					}
					
					
					
				} catch (SQLException e) {
					e.printStackTrace();
				} finally {
					if(conn!=null) 
						DBUtils.closeConnection(conn);
				}
				
				
				return null;
				
			}
		};

	}

	@Test
	public void testCreateGroupWithNull() throws Exception {
		try {
			manager.createGroup(null);
			fail("created null group");
		} catch (NullPointerException e) {}
	}

	@Test
	public void testCreateGroupWithSetID() throws Exception {
		Group group = new Group();
		group.setId(0L);
		try {
			manager.createGroup(group);
			fail("created group with id set");
		} catch (IllegalArgumentException e) {}
	}


	@Test
	public void testCreateGroupId() throws Exception {
		Group group = new Group();
		group.setName("newGroup");
		Group newGroup = manager.createGroup(group);
		assertNotNull(newGroup.getId());
		Group anotherGroup = manager.createGroup(new Group(group));
		assertNotNull(anotherGroup.getId());
		assertNotSame(newGroup.getId().longValue(), anotherGroup.getId().longValue());
		assertEquals(group.getName(), newGroup.getName());
	}

	@Test
	public void testCreateAndFindGroup() throws Exception {
		Group group = new Group();
		group.setName("new group");
		group = manager.createGroup(group);
		Group group2 = new Group();
		group2.setName("another new group");
		group2 = manager.createGroup(group2);
		Group result2 = manager.findGroupById(group2.getId());
		Group result = manager.findGroupById(group.getId());
		assertNotSame(group, result);
		assertNotSame(group2, result2);
		assertDeepEquals(group, result);
		assertDeepEquals(group2, result2);
	}



	@Test
	public void testDeleteGroupWithNoID() throws Exception {
		Group group = new Group();
		try {
			manager.deleteGroup(group);
			fail("deleted group with no id");
		} catch (IllegalArgumentException e) {}
	}

	@Test
	public void testDeleteGroupWithNull() throws Exception {
		try {
			manager.deleteGroup(null);
			fail("deleted null group");
		} catch(NullPointerException e) {}
	}

	@Test
	public void testDeleteGroup() throws Exception {
		Group group = new Group();
		group.setName("test");
		Group group2 = new Group();
		group2.setName("unaffected group"); 

		group = manager.createGroup(group);
		group2 = manager.createGroup(group2);
		manager.deleteGroup(group);
		assertThat(manager.findAllGroups(), not(hasItem(group)));
		assertNull(manager.findGroupById(group.getId()));
		//unaffected group
		assertDeepEquals(group2,  manager.findGroupById(group2.getId()));
	}

	@Test
	public void testUpdateGroupWithNull() throws Exception {
		try {
			manager.updateGroup(null);
			fail("updated null group");
		} catch (NullPointerException e) {}
	}

	@Test
	public void testUpdateGroupWithNoID() throws Exception {
		Group group = new Group();
		try {
			manager.updateGroup(group);
			fail("updated group with no id");
		} catch(IllegalArgumentException e) {}
	}

	@Test
	public void testUpdateGroup() throws Exception {
		Group group = new Group();
		group.setName("Testing group");
		group = manager.createGroup(group);

		Group group2 = new Group();
		group2.setName("Unaffected group");
		group2 = manager.createGroup(group2);

		group.setName("Updated group");
		manager.updateGroup(group);
		assertDeepEquals(group, manager.findGroupById(group.getId()));
		//unaffected group
		assertDeepEquals(group2, manager.findGroupById(group2.getId()));
	}

	@Test
	public void testFindGroupByIdWithNull() throws Exception {
		try {
			manager.findGroupById(null);
			fail("found null group");
		} catch (NullPointerException e) {}
	}

	@Test
	public void testFindGroupByIdNonExistent() throws Exception {
		assertNull(manager.findGroupById(Long.MIN_VALUE));
	}


	@Test
	public void testFindAllGroups() throws Exception {
		Group group1 = new Group();
		Group group2 = new Group();
		group1 = manager.createGroup(group1);
		group2 = manager.createGroup(group2);

		List<Group> expected = Arrays.asList(group1, group2);
		List<Group> result = manager.findAllGroups();

		assertNotNull(result);
		assertThat(result, hasItem(group1));
		assertThat(result, hasItem(group2));

	}

	@Test
	public void testAddPersonToGroupWithNull() throws Exception {
		Group group = new Group();
		group.setId(1L);
		Person person = new Person();
		person.setId(2L);

		try {
			manager.addPersonToGroup(null, group);
			fail("aded null person to group");
		} catch (NullPointerException e) {}

		try {
			manager.addPersonToGroup(person, null);
			fail("added person to null group");
		} catch (NullPointerException e) {}

	}

	@Test
	public void testAddPersonToGroupIllegalArguments() throws Exception {
		Group group = new Group();
		Person person = new Person();
		group.setId(1L);

		try {
			manager.addPersonToGroup(person, group);
			fail("added noID person to group");
		} catch (IllegalArgumentException e) {}

		group = new Group();
		person.setId(2L);
		try {
			manager.addPersonToGroup(person, group);
			fail("added person to noID group");
		} catch (IllegalArgumentException e) {}

	}

	@Test
	public void testAddPersonToGroupAndFind() throws Exception {
		Group group1 = new Group();
		group1.setName("First group");
		Group group2 = new Group();
		group2.setName("Second group");
		Person person1 = new Person();
		person1.setName("First person");
		Person person2 = new Person();
		person2.setName("Second person");

		PersonManager personManager = getPersonManagerInstance();

		group1 = manager.createGroup(group1);
		group2 = manager.createGroup(group2);
		person1 = personManager.createPerson(person1);
		person2 = personManager.createPerson(person2);

		manager.addPersonToGroup(person1, group1);
		manager.addPersonToGroup(person1, group2);
		manager.addPersonToGroup(person2, group1);

		List<Person> people = manager.findAllPersonsInGroup(group1);
		assertThat(people, hasItem(person1));
		assertThat(people, hasItem(person2));

		people = manager.findAllPersonsInGroup(group2);
		assertThat(people, hasItem(person1));
		assertThat(people, not(hasItem(person2)));

		List<Group> groups = manager.findGroupsByPerson(person1);
		assertThat(groups, hasItem(group1));
		assertThat(groups, hasItem(group2));

		groups = manager.findGroupsByPerson(person2);
		assertThat(groups, hasItem(group1));
		assertThat(groups, not(hasItem(group2)));

	}

	@Test
	public void testRemovePersonFromGroupWithNull() throws Exception {
		Group group = new Group();
		group.setId(1L);
		try {
			manager.removePersonFromGroup(null, group);
		} catch (NullPointerException e) {}

		Person person = new Person();
		person.setId(2L);

		try {
			manager.removePersonFromGroup(person, null);
		} catch (NullPointerException e) {}
	}

	@Test
	public void testRemovePersonFromGroupWithIllegalArguments() throws Exception {
		Group group = new Group();
		group.setId(1L);

		try {
			manager.removePersonFromGroup(new Person(), group);
			fail("removed person with null id from group");
		} catch (IllegalArgumentException e) {}

		Person person = new Person();
		person.setId(2L);

		try {
			manager.removePersonFromGroup(person, new Group());
			fail("removed person from group with null id");
		} catch (IllegalArgumentException e) {}
	}

	@Test
	public void testRemovePersonFromGroup() throws Exception {
		Person p1 = new Person();
		Person p2 = new Person();

		Group g1 = new Group();
		Group g2 = new Group();

		g1 = manager.createGroup(g1);
		g2 = manager.createGroup(g2);

		PersonManager personManager = getPersonManagerInstance();
		p1 = personManager.createPerson(p1);
		p2 = personManager.createPerson(p2);

		//add people to groups
		manager.addPersonToGroup(p1, g1);
		manager.addPersonToGroup(p1, g2);
		manager.addPersonToGroup(p2, g1);

		manager.removePersonFromGroup(p1, g2);
		manager.removePersonFromGroup(p2, g1);
		manager.removePersonFromGroup(p2, g2);

		//verify correctness
		List<Person> people1 = manager.findAllPersonsInGroup(g1);
		assertThat(people1, hasItem(p1));
		assertThat(manager.findAllPersonsInGroup(g2), not(hasItem(p1)));
		assertThat(people1, not(hasItem(p2)));

		List<Group> groups1 = manager.findGroupsByPerson(p1);
		assertThat(groups1, hasItem(g1));
		assertThat(groups1, not(hasItem(g2)));


	}

	@Test
	public void testFindGroupsByPersonWithNull() throws Exception {
		try {
			manager.findGroupsByPerson(null);
			fail("found groups by null person");
		} catch (NullPointerException e) {}
	}

	@Test
	public void testFindGroupsByPersonWithIllegalArguments() throws Exception {
		try {
			manager.findGroupsByPerson(new Person());
			fail("found groups by person with null id");
		} catch (IllegalArgumentException e) {}
	}


	@Test
	public void testFindAllPersonsInGroupWithNull() throws Exception {
		try {
			manager.findAllPersonsInGroup(null);
			fail("found people by null group");
		} catch(NullPointerException e) {}
	}

	@Test
	public void testFindAllPersonsInGroup() throws Exception {
		try {
			manager.findAllPersonsInGroup(new Group());
			fail("found people by group with null id");
		} catch (IllegalArgumentException e) {}
	}

	private void assertDeepEquals(List<Group> expected, List<Group> result) {
		assertEquals(expected.size(), result.size());
		for (int i = 0; i < expected.size(); i++) {
			assertDeepEquals(expected.get(i), result.get(i));
		}
	}

	private void assertDeepEquals(Group expected, Group result) {
		assertEquals(expected.getId(), result.getId());
		assertEquals(expected.getName(), result.getName());
	}

	private static Comparator<Group> idComparator = new Comparator<Group>() {
		@Override
		public int compare(Group group, Group group1) {
			return group.getId().compareTo(group1.getId());
		}
	};
}
