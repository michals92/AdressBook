package cz.muni.fi.pv168;

import org.apache.commons.logging.Log;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import static org.hamcrest.CoreMatchers.*;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;
import static org.junit.matchers.JUnitMatchers.hasItem;

/**
 * Tests for PersonManagerImpl. Assume that create person returns the same instance. And if test are ok then delete test data from datastore.
 * User: zitoo
 * Date: 28.3.12
 * Time: 10:10
 */
public class PersonManagerImplTest {
    private static ApplicationContext ctx=null;
    PersonManager personManager=null;
    private static final Logger log = LoggerFactory.getLogger(PersonManagerImplTest.class);

    @BeforeClass
    public static void beforeClass(){
        ctx = new AnnotationConfigApplicationContext(DBUtils.SpringConfig.class);
    }

    @Before
    public void setUp() throws Exception {
        personManager = ctx.getBean("personManager", PersonManager.class);
    }

    @Test
    public void testCreatePersonWithNull() throws Exception {
        try{
            personManager.createPerson(null);
            fail("Should have thrown NullPointerException");
        } catch(NullPointerException e){}

    }
    
    @Test
    public void testCreatePersonWithIdSet() throws Exception{
        try{
            Person person = new Person();
            person.setName("testCreatePersonWithIdSet");
            person.setId(0l);
            personManager.createPerson(person);
            fail("Should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException e) {}                                         
    }
    
    @Test
    public void testCreatePersonGenerateId() throws Exception{
        Person person = new Person();
        person.setName("testCreatePersonGenerateId");
        Person person1 = personManager.createPerson(person);
        assertThat(person1.getId(), is(not(equalTo(null))));
        personManager.deletePerson(person1);
    }
    
    @Test 
    public void testCreatePersonUniqueId() throws Exception{
        Person person = personManager.createPerson(new Person());
        Person person1 = personManager.createPerson(new Person());
        assertThat(person, is(not(equalTo(person1))));
        personManager.deletePerson(person);
        personManager.deletePerson(person1);
    }

    @Test
    public void testCreatePerson() throws Exception{
        Person person = new Person();
        person.setName("testCreatePerson");
        person.setBorn(Calendar.getInstance());
        Person person1 = personManager.createPerson(person);
        assertThat(person, is(equalTo(person1)));
        personManager.deletePerson(person1);
    }


    @Test
    public void testCreateAndFindAllPersons() throws Exception {
        List<Person> list = personManager.findAllPersons();
        Person person = new Person();
        Person person1 = new Person();
        Person person2 = new Person();
        personManager.createPerson(person);
        list.add(person);
        personManager.createPerson(person1);
        list.add(person1);
        personManager.createPerson(person2);
        list.add(person2);
        assertThat(list, is(equalTo(personManager.findAllPersons())));

        personManager.deletePerson(person);
        personManager.deletePerson(person1);
        personManager.deletePerson(person2);
    }

    @Test
    public void testFindPersonByIdNull() throws Exception {
        try{
            personManager.findPersonById(null);
            fail("Should have thrown NullPointerException");
        } catch (NullPointerException e) {}
    }

    @Test
    public void testCreateAndFindPersonById() throws Exception{
        Person person = personManager.createPerson(new Person());
        Person person1 = personManager.findPersonById(person.getId());
        assertThat(person, is(equalTo(person1)));

        personManager.deletePerson(person);
    }

    @Test
    public void testUpdatePersonWithNull() throws Exception {
        try{
            personManager.updatePerson(null);
            fail("Should have thrown NullPointerException");
        } catch (NullPointerException e) {}
    }

    @Test
    public void testUpdatePersonWithNoId() throws Exception{
        Person person = new Person();
        try{
            personManager.updatePerson(person);
            fail("Should have thrown IllegalArgumentException");
        } catch (IllegalArgumentException e) {}
    }

    @Test
    public void testUpdatePerson() throws Exception{
        Person person = new Person();
        person.setName("testUpdatePerson");
        person.setBorn(Calendar.getInstance());
        personManager.createPerson(person);

        person.setName("testUpdatePerson - updated");
        person.setBorn(Calendar.getInstance());
        personManager.updatePerson(person);

        Person updatedPerson = personManager.findPersonById(person.getId());
        assertThat(person, is(equalTo(updatedPerson)));

        personManager.deletePerson(person);
    }

    @Test
    public void testDeletePersonWithNull() throws Exception {
        try{
            personManager.deletePerson(null);
            fail("Should have thrown NullPointerException");
        } catch(NullPointerException e) {}
    }
    
    @Test
    public void testDeletePersonWithNoId() throws Exception{
        Person person = new Person();
        try{
            personManager.deletePerson(person);
            fail("Sould have thrown IllegalArgumentException");
        } catch (IllegalArgumentException e) {}
    }
    
    @Test
    public void testDeletePerson() throws Exception {
        Person person = new Person();
        personManager.createPerson(person);
        assertThat(personManager.findAllPersons(), hasItem(person));
        personManager.deletePerson(person);
        assertThat(personManager.findAllPersons(), not(hasItem(person)));
    }
}
