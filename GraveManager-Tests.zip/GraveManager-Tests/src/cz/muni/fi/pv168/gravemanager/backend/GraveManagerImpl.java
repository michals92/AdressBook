/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.muni.fi.pv168.gravemanager.backend;

import java.util.List;

/**
 * This class implements GraveManager.
 * 
 * @author Petr Adamek
 */
public class GraveManagerImpl implements GraveManager {

    @Override
    public void createGrave(Grave grave) throws ServiceFailureException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public Grave getGrave(Long id) throws ServiceFailureException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void updateGrave(Grave grave) throws ServiceFailureException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void deleteGrave(Grave grave) throws ServiceFailureException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<Grave> findAllGraves() throws ServiceFailureException {
        throw new UnsupportedOperationException("Not supported yet.");
    }

}
