/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cz.muni.fi.pv168.autorental.backend;

import java.math.BigDecimal;
import java.sql.Date;

/**
 *
 * @author Ladislav
 */
public class CostCalculator {
    
}
