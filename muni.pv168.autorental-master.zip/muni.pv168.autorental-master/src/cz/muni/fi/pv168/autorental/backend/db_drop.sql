DROP TABLE rents;
DROP TABLE cars;
DROP TABLE customers;